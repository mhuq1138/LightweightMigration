//
//  EditViewController.swift
//  PersonList
//
//  Created by Mazharul Huq on 3/8/18.
//  Copyright © 2018 Mazharul Huq. All rights reserved.
//

import UIKit
import CoreData

class EditViewController: UIViewController {

    @IBOutlet var firstNameField: UITextField!
    
    var context: NSManagedObjectContext!
    var person:Person?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.firstNameField.text = person?.firstName
        
    }
    
    @IBAction func saveTapped(_ sender: Any) {
        if  self.person  == nil {
            self.person = Person(context: self.context)
        }
        self.person?.firstName = self.firstNameField.text
        do {
            try self.context.save()
        }
        catch{
            print("error in saving changes")
        }
        
        self.navigationController?.popViewController(animated: true)
    }
    
}
