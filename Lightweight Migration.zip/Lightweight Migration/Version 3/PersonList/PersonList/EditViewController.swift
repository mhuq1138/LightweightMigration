//
//  EditViewController.swift
//  PersonList
//
//  Created by Mazharul Huq on 3/8/18.
//  Copyright © 2018 Mazharul Huq. All rights reserved.
//

import UIKit
import CoreData

class EditViewController: UIViewController {

    @IBOutlet var firstNameField: UITextField!
    @IBOutlet var lastNameField: UITextField!
    @IBOutlet var ageField: UITextField!
    @IBOutlet var streetField: UITextField!
    
    var context: NSManagedObjectContext!
    var person:Person?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.firstNameField.text = person?.firstName
        self.lastNameField.text = person?.lastName
        self.streetField.text = person?.address?.street
        guard let age = person?.age else{
            return
        }
        self.ageField.text = String(describing: age)
        
    }
    
    @IBAction func saveTapped(_ sender: Any) {
        var address:Address
        if  self.person  == nil {
            self.person = Person(context: self.context)
            address = Address(context: self.context)
        }
        else{
            if let add = person?.address{
                address = add
            }
            else{
               address = Address(context: self.context)
            }
        }
        self.person?.firstName = self.firstNameField.text
        self.person?.lastName = self.lastNameField.text
        self.person?.age = Int16(self.ageField.text!)!
        
        address.street = self.streetField.text
        address.person = person
        do {
            try self.context.save()
        }
        catch{
            print("error in saving changes")
        }
        
        self.navigationController?.popViewController(animated: true)
    }
    
}
