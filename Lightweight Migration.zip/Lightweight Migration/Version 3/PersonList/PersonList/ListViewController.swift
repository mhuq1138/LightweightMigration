//
//  ListViewController.swift
//  PersonList
//
//  Created by Mazharul Huq on 3/8/18.
//  Copyright © 2018 Mazharul Huq. All rights reserved.
//

import UIKit
import CoreData

class ListViewController: UITableViewController {

    lazy var coreDataStack = CoreDataStack(modelName: "PersonList")
    lazy var fetchedResultsController:NSFetchedResultsController<Person> = {
        
        let fetchRequest:NSFetchRequest<Person> =  Person.fetchRequest()
        let sortDescriptor =
            NSSortDescriptor(key: "firstName", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        let  frc:NSFetchedResultsController<Person> = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: self.coreDataStack.managedContext, sectionNameKeyPath: nil, cacheName: nil)
        frc.delegate = self
        return frc
        
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.leftBarButtonItem = self.editButtonItem
        
        print(coreDataStack.storeContainer.persistentStoreDescriptions)
        do {
            try fetchedResultsController.performFetch()
        } catch let error as NSError {
            print("Error: \(error.localizedDescription)")
            abort()
        }
    }
    
    func configureCell(_ cell: UITableViewCell, indexPath: IndexPath) {
        let person = fetchedResultsController.object(at: indexPath)
        
        let firstName = person.firstName ?? ""
        let lastName = person.lastName ?? ""
        let age = person.age
        cell.textLabel?.text = firstName + "  " + lastName
        
        if age > 0{
            cell.textLabel?.text = firstName + "  " + lastName + "   Age: \(age)"
        }
        else{
            cell.textLabel?.text = firstName + "  " + lastName
        }
        cell.detailTextLabel?.text = person.address?.street
        
    }
    
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        guard let sections = self.fetchedResultsController.sections else{
            return  0
        }
        return sections.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let sections = self.fetchedResultsController.sections else{
            return  0
        }
        return sections[section].numberOfObjects
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        self.configureCell(cell, indexPath: indexPath)
        return cell
    }
    
    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    
    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let person = self.fetchedResultsController.object(at: indexPath)
            self.fetchedResultsController.managedObjectContext.delete(person)
            do{
                try self.fetchedResultsController.managedObjectContext.save()
            }
            catch{
                print("Cannot delete record from store")
            }
            
        }
    }
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let vc = segue.destination as? EditViewController else{
            return
        }
        vc.context = self.coreDataStack.managedContext
        if segue.identifier == "edit"{
            guard let indexPath = self.tableView.indexPathForSelectedRow else{
                return
            }
            vc.person = self.fetchedResultsController.object(at: indexPath)
        }
    }
}

 //NSFetchedResultsController Delegate methods

extension ListViewController:NSFetchedResultsControllerDelegate{
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.beginUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            tableView.insertRows(at: [newIndexPath!],with: .automatic)
        case .delete:
            tableView.deleteRows(at: [indexPath!],with: .automatic)
        case .update:
            let cell = tableView.cellForRow(at: indexPath!)as UITableViewCell!
            configureCell(cell!, indexPath: indexPath!)
        case .move:
            tableView.deleteRows(at: [indexPath!],with: .automatic)
            tableView.insertRows(at: [newIndexPath!],with: .automatic)
        }
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
        let indexSet = IndexSet(integer: sectionIndex)
        switch type {
        case .insert:
            tableView.insertSections(indexSet,with: .automatic)
        case .delete:
            tableView.deleteSections(indexSet,with: .automatic)
        default :
            break
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.endUpdates()
    }
}

