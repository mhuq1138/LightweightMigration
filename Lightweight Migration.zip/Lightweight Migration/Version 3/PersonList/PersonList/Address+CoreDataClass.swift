//
//  Address+CoreDataClass.swift
//  PersonList
//
//  Created by Mazharul Huq on 3/8/18.
//  Copyright © 2018 Mazharul Huq. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Address)
public class Address: NSManagedObject {

}
